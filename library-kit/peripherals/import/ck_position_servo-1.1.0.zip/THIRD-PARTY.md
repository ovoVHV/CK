# 上游驱动

- Servo 1.2.2 (LGPL-2.1-or-later)：https://github.com/arduino-libraries/Servo
  - 下载：https://downloads.arduino.cc/libraries/github.com/arduino-libraries/Servo-1.2.2.zip
  - 下载 SHA-256：`60850b4c644aa4239706fa50ca09a49c99fb98b0e0f2fb84b30022b82428908b`
  - 原许可证：`libraries/Servo/LICENSE.txt`
