# 上游驱动

- DHT_sensor_library 1.4.6 (MIT)：https://github.com/adafruit/DHT-sensor-library
  - 下载：https://downloads.arduino.cc/libraries/github.com/adafruit/DHT_sensor_library-1.4.6.zip
  - 下载 SHA-256：`20a9048e72d636305470c347bd8f83c01d4178c87ff865cae47a7276315e36c2`
  - 原许可证：`libraries/DHT_sensor_library/license.txt`
- Adafruit_Unified_Sensor 1.1.15 (Apache-2.0)：https://github.com/adafruit/Adafruit_Sensor
  - 下载：https://downloads.arduino.cc/libraries/github.com/adafruit/Adafruit_Unified_Sensor-1.1.15.zip
  - 下载 SHA-256：`d64cdec0b817535f568fc3b8b8d44e7e097749f5ab8040aea573f412a3cbaec6`
  - 原许可证：`libraries/Adafruit_Unified_Sensor/LICENSE.txt`
