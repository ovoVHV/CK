{
  "format": "ck-project",
  "schema_version": 1,
  "migration_version": 1,
  "name": "SSD1306 OLED 进度显示 演示",
  "board": "arduino:avr:uno",
  "board_package_id": "arduino:avr:uno",
  "options": "{}",
  "xml": "{\"blocks\":{\"languageVersion\":0,\"blocks\":[{\"type\":\"controls_setup_custom\",\"id\":\"ck_oled_ssd1306-setup\",\"inputs\":{\"DO\":{\"block\":{\"type\":\"serial_setup\",\"id\":\"ck_oled_ssd1306-serial\",\"inputs\":{\"BAUD\":{\"shadow\":{\"type\":\"math_number\",\"fields\":{\"NUM\":9600}}}},\"next\":{\"block\":{\"type\":\"ck_oled_ssd1306_begin\",\"id\":\"ck_oled_ssd1306-config\",\"inputs\":{\"ADDR\":{\"shadow\":{\"type\":\"math_number\",\"fields\":{\"NUM\":60}}}},\"next\":{\"block\":{\"type\":\"ck_oled_ssd1306_invert\",\"id\":\"ck_oled_ssd1306-normal\",\"inputs\":{\"ENABLE\":{\"shadow\":{\"type\":\"math_number\",\"fields\":{\"NUM\":0}}}}}}}}}}},\"x\":36,\"y\":38},{\"type\":\"controls_loop_custom\",\"id\":\"ck_oled_ssd1306-loop\",\"inputs\":{\"DO\":{\"block\":{\"type\":\"ck_oled_ssd1306_bar\",\"id\":\"ck_oled_ssd1306-low\",\"inputs\":{\"VALUE\":{\"shadow\":{\"type\":\"math_number\",\"fields\":{\"NUM\":25}}}},\"next\":{\"block\":{\"type\":\"controls_delay\",\"id\":\"ck_oled_ssd1306-a\",\"inputs\":{\"DELAY_TIME\":{\"shadow\":{\"type\":\"math_number\",\"fields\":{\"NUM\":800}}}},\"next\":{\"block\":{\"type\":\"ck_oled_ssd1306_bar\",\"id\":\"ck_oled_ssd1306-high\",\"inputs\":{\"VALUE\":{\"shadow\":{\"type\":\"math_number\",\"fields\":{\"NUM\":75}}}},\"next\":{\"block\":{\"type\":\"serial_print\",\"id\":\"ck_oled_ssd1306-status\",\"inputs\":{\"MSG\":{\"block\":{\"type\":\"ck_oled_ssd1306_ready\",\"id\":\"ck_oled_ssd1306-read\"}}},\"fields\":{\"NEWLINE\":\"TRUE\"},\"next\":{\"block\":{\"type\":\"controls_delay\",\"id\":\"ck_oled_ssd1306-b\",\"inputs\":{\"DELAY_TIME\":{\"shadow\":{\"type\":\"math_number\",\"fields\":{\"NUM\":800}}}}}}}}}}}}}}},\"x\":520,\"y\":38}]}}"
}
