# SSD1306 OLED 进度显示 1.0.0

在一块 128×64 I²C SSD1306 上显示横向进度，支持反色和通信状态。

## 导入和接线

在 CK 选择示例板卡，再通过「库管理器 → 导入」选择本库 ZIP。导入后可在工具箱打开「SSD1306 OLED 进度显示」分类。解压 ZIP 后打开 `examples/demo.ck`。

GND 共地。确认模块供电和逻辑电平；Uno 默认 SDA=A4、SCL=A5；通用 ESP32-S3 Dev Module 默认 SDA=GPIO8、SCL=GPIO9，I²C 上拉至 3.3 V。

## 正常示例

上电清屏；屏幕中部在 25% 和 75% 的横条之间切换。串口 9600 打印最近一次通信是否成功；ACK 不证明屏幕可见。

仅支持带复位电路的 4 针模块与内置电荷泵；非 SPI、SH1106 或 128×32 驱动。一组积木只管理一块屏。通信失败后重新初始化。

## 积木

- **初始化 SSD1306 OLED 地址**：启动默认 Wire，清空 128×64 显存，打开显示。
- **OLED 显示进度 %**：重画中部 8 像素高的进度条。
- **OLED 反色 开(1)/关(0)**：切换正常显示与反色显示。
- **OLED 通信正常？**：返回最近一次写入是否收到应答，不主动探测。

## 诊断示例

打开 `examples/invalid.ck` 并编译。将填错的 62 改为 60（0x3C）。 预期实例：`ck_oled_ssd1306-config`；诊断：`CK_OLED_ADDRESS`。详细机读预期见 `examples/expected.json`。

## 支持范围

Uno 使用 demo.ck / invalid.ck；ESP32-S3（Arduino Core 3.x）使用 demo-s3.ck / invalid-s3.ck。其他板卡未验收。编译不代表接线或硬件实测。驱动来源与原许可证见 [THIRD-PARTY.md](THIRD-PARTY.md)。
